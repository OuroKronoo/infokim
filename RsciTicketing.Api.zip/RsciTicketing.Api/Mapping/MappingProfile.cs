namespace RsciTicketing.Api.Mapping;

/// <summary>All Entity &lt;-&gt; DTO mappings live here, so controllers never expose EF entities.</summary>
public class MappingProfile : Profile
{
    public MappingProfile()
    {
        // Users
        CreateMap<User, UserDto>();
        CreateMap<CreateUserDto, User>().ForMember(d => d.IsActive, o => o.MapFrom(_ => true));

        // Projects, suppliers, inventory
        CreateMap<Project, ProjectDto>();
        CreateMap<SaveProjectDto, Project>();
        CreateMap<Supplier, SupplierDto>();
        CreateMap<SaveSupplierDto, Supplier>();
        CreateMap<InventoryItem, InventoryItemDto>()
            .ForMember(d => d.IsLowStock, o => o.MapFrom(s => s.QtyOnHand <= s.ReorderLevel));
        CreateMap<SaveInventoryItemDto, InventoryItem>();

        CreateMap<StockMovement, StockMovementDto>()
            .ForMember(d => d.ItemName, o => o.MapFrom(s => s.Item.Name))
            .ForMember(d => d.PerformedByName, o => o.MapFrom(s => s.PerformedBy.FullName));

        // Tickets
        CreateMap<TicketItem, TicketItemDto>()
            .ForMember(d => d.ItemName, o => o.MapFrom(s => s.Item.Name))
            .ForMember(d => d.Unit, o => o.MapFrom(s => s.Item.Unit));
        CreateMap<Ticket, TicketDto>()
            .ForMember(d => d.ProjectName, o => o.MapFrom(s => s.Project.Name))
            .ForMember(d => d.RequestedByName, o => o.MapFrom(s => s.RequestedBy.FullName))
            .ForMember(d => d.OverrideApproved, o => o.MapFrom(s => s.OverrideApprovedById != null))
            .ForMember(d => d.Items, o => o.MapFrom(s => s.TicketItems));

        // Purchase orders
        CreateMap<PurchaseOrderItem, PurchaseOrderItemDto>()
            .ForMember(d => d.ItemName, o => o.MapFrom(s => s.Item.Name))
            .ForMember(d => d.LineTotal, o => o.MapFrom(s => s.Qty * s.UnitPrice));
        CreateMap<PurchaseOrder, PurchaseOrderDto>()
            .ForMember(d => d.TicketNo, o => o.MapFrom(s => s.Ticket.TicketNo))
            .ForMember(d => d.SupplierName, o => o.MapFrom(s => s.Supplier.Name))
            .ForMember(d => d.CreatedByName, o => o.MapFrom(s => s.CreatedBy.FullName))
            .ForMember(d => d.Items, o => o.MapFrom(s => s.PurchaseOrderItems));
    }
}
