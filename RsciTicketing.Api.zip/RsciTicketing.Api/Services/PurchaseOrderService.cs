namespace RsciTicketing.Api.Services;

public class PurchaseOrderService(RsciDbContext db, IMapper mapper, ActorService actors)
{
    private static readonly string[] Editors = [Roles.PoOfficer, Roles.Requisitor];

    // ---------- reads ----------
    public async Task<List<PurchaseOrderDto>> ListAsync(string? status, int? ticketId)
    {
        var q = db.PurchaseOrders.AsNoTracking();
        if (!string.IsNullOrWhiteSpace(status)) q = q.Where(p => p.Status == status);
        if (ticketId != null) q = q.Where(p => p.TicketId == ticketId);

        return await q.OrderByDescending(p => p.CreatedAt)
                      .ProjectTo<PurchaseOrderDto>(mapper.ConfigurationProvider)
                      .ToListAsync();
    }

    public async Task<PurchaseOrderDto> GetAsync(int id) =>
        await db.PurchaseOrders.AsNoTracking().Where(p => p.PurchaseOrderId == id)
                .ProjectTo<PurchaseOrderDto>(mapper.ConfigurationProvider)
                .FirstOrDefaultAsync()
        ?? throw DomainException.NotFound($"Purchase order {id} was not found.");

    private async Task<PurchaseOrder> LoadAsync(int id) =>
        await db.PurchaseOrders
                .Include(p => p.PurchaseOrderItems).ThenInclude(i => i.Item)
                .Include(p => p.Ticket).ThenInclude(t => t.TicketItems)
                .FirstOrDefaultAsync(p => p.PurchaseOrderId == id)
        ?? throw DomainException.NotFound($"Purchase order {id} was not found.");

    // ---------- create / edit / void (PO Officer or Requisitor) ----------
    public async Task<PurchaseOrderDto> CreateAsync(CreatePurchaseOrderDto dto)
    {
        await actors.RequireAsync(dto.CreatedById, Editors);

        var ticket = await db.Tickets.Include(t => t.TicketItems)
                         .FirstOrDefaultAsync(t => t.TicketId == dto.TicketId)
                     ?? throw DomainException.NotFound($"Ticket {dto.TicketId} was not found.");

        if (ticket.Status is not (TicketStatus.PoCreation or TicketStatus.PoQueue))
            throw DomainException.Conflict($"Ticket is '{ticket.Status}'. A P.O. can only be built for tickets that still need purchasing.");

        await EnsureSupplierAsync(dto.SupplierId);

        var po = new PurchaseOrder
        {
            PoNo = "TMP-" + Guid.NewGuid().ToString("N")[..12],
            TicketId = ticket.TicketId,
            SupplierId = dto.SupplierId,
            Status = PoStatus.PendingApproval,
            CreatedById = dto.CreatedById,
            CreatedAt = DateTime.UtcNow
        };
        ApplyLines(po, ticket, dto.Items);

        db.PurchaseOrders.Add(po);
        await db.SaveChangesAsync();

        po.PoNo = $"PO-{po.CreatedAt:yyyy}-{po.PurchaseOrderId:D5}";
        await db.SaveChangesAsync();
        return await GetAsync(po.PurchaseOrderId);
    }

    public async Task<PurchaseOrderDto> UpdateAsync(int id, UpdatePurchaseOrderDto dto)
    {
        await actors.RequireAsync(dto.UserId, Editors);
        var po = await LoadAsync(id);

        if (po.Status is not (PoStatus.PendingApproval or PoStatus.Rejected))
            throw DomainException.Conflict($"P.O. is '{po.Status}'. Only pending or rejected P.O.s can be edited.");

        await EnsureSupplierAsync(dto.SupplierId);

        var old = po.PurchaseOrderItems.ToList();
        UndoLines(po, po.Ticket);
        db.PurchaseOrderItems.RemoveRange(old);
        po.PurchaseOrderItems.Clear();

        po.SupplierId = dto.SupplierId;
        ApplyLines(po, po.Ticket, dto.Items);

        // Editing a rejected P.O. resubmits it for approval.
        po.Status = PoStatus.PendingApproval;
        po.RejectionReason = null; po.ApprovedById = null; po.ApprovedAt = null;

        await db.SaveChangesAsync();
        return await GetAsync(id);
    }

    /// <summary>No hard delete: voiding keeps the document and its P.O. number as the audit trail.</summary>
    public async Task<PurchaseOrderDto> VoidAsync(int id, int userId, string? reason)
    {
        await actors.RequireAsync(userId, Editors);
        if (string.IsNullOrWhiteSpace(reason))
            throw DomainException.BadRequest("A reason is required to void a P.O.");

        var po = await LoadAsync(id);
        if (po.Status is not (PoStatus.PendingApproval or PoStatus.Rejected or PoStatus.Approved or PoStatus.AwaitingPaymentRelease))
            throw DomainException.Conflict($"P.O. is '{po.Status}'. Payment has already been released, so it can no longer be voided.");

        UndoLines(po, po.Ticket);
        po.Status = PoStatus.Cancelled;
        po.VoidReason = reason.Trim();

        await db.SaveChangesAsync();
        return await GetAsync(id);
    }

    // ---------- approval: Boss or OM (either clears it) ----------
    public async Task<PurchaseOrderDto> ApproveAsync(int id, ActorDto dto)
    {
        var actor = await actors.RequireAsync(dto.UserId, Roles.Approvers);
        var po = await LoadAsync(id);
        if (po.Status != PoStatus.PendingApproval)
            throw DomainException.Conflict($"P.O. is '{po.Status}', not waiting for approval.");

        po.Status = PoStatus.Approved;
        po.ApprovedById = actor.UserId;
        po.ApprovedAt = DateTime.UtcNow;

        await db.SaveChangesAsync();
        return await GetAsync(id);
    }

    public async Task<PurchaseOrderDto> RejectAsync(int id, ReasonDto dto)
    {
        await actors.RequireAsync(dto.UserId, Roles.Approvers);
        var po = await LoadAsync(id);

        var rushStillOpen = po.RushNoApproval &&
                            po.Status is PoStatus.Approved or PoStatus.AwaitingPaymentRelease;
        if (po.Status != PoStatus.PendingApproval && !rushStillOpen)
            throw DomainException.Conflict($"P.O. is '{po.Status}' and can no longer be rejected.");

        po.Status = PoStatus.Rejected;
        po.RejectionReason = dto.Reason.Trim();
        po.ApprovedById = null; po.ApprovedAt = null;

        await db.SaveChangesAsync();
        return await GetAsync(id);
    }

    /// <summary>Rush exception: the PO Officer skips approval with a mandatory reason; it is flagged so it is never mistaken for a real sign-off.</summary>
    public async Task<PurchaseOrderDto> RushAsync(int id, ReasonDto dto)
    {
        await actors.RequireAsync(dto.UserId, Roles.PoOfficer);
        var po = await LoadAsync(id);
        if (po.Status != PoStatus.PendingApproval)
            throw DomainException.Conflict($"P.O. is '{po.Status}', not waiting for approval.");

        po.RushNoApproval = true;
        po.RushReason = dto.Reason.Trim();
        po.Status = PoStatus.Approved;

        await db.SaveChangesAsync();
        return await GetAsync(id);
    }

    // ---------- payment chain ----------
    public async Task<PurchaseOrderDto> IssueOrderOfPaymentAsync(int id, ActorDto dto)
    {
        await actors.RequireAsync(dto.UserId, Roles.Accountant);
        var po = await LoadAsync(id);
        if (po.Status != PoStatus.Approved)
            throw DomainException.Conflict($"P.O. is '{po.Status}'. An Order of Payment needs an approved P.O.");

        po.OrderOfPaymentNo = $"OP-{DateTime.UtcNow:yyyy}-{po.PurchaseOrderId:D5}";
        po.Status = PoStatus.AwaitingPaymentRelease;

        await db.SaveChangesAsync();
        return await GetAsync(id);
    }

    public async Task<PurchaseOrderDto> ReleasePaymentAsync(int id, ActorDto dto)
    {
        await actors.RequireAsync(dto.UserId, Roles.Boss);
        var po = await LoadAsync(id);
        if (po.Status != PoStatus.AwaitingPaymentRelease)
            throw DomainException.Conflict($"P.O. is '{po.Status}', not awaiting payment release.");

        po.Status = PoStatus.PaymentReleased;
        po.PaymentReleasedAt = DateTime.UtcNow;

        await db.SaveChangesAsync();
        return await GetAsync(id);
    }

    public async Task<PurchaseOrderDto> ConfirmPurchasedAsync(int id, ConfirmPurchasedDto dto)
    {
        await actors.RequireAsync(dto.UserId, Roles.Accountant);
        var po = await LoadAsync(id);
        if (po.Status != PoStatus.PaymentReleased)
            throw DomainException.Conflict($"P.O. is '{po.Status}'. Payment must be released before confirming the purchase.");

        po.SiOrNo = dto.SiOrNo.Trim();
        po.Status = PoStatus.Purchased;
        po.PurchasedAt = DateTime.UtcNow;

        await db.SaveChangesAsync();
        return await GetAsync(id);
    }

    // ---------- delivery: Inventory Manager ----------
    public async Task<PurchaseOrderDto> ReceiveAsync(int id, ActorDto dto)
    {
        var actor = await actors.RequireAsync(dto.UserId, Roles.InventoryManager);
        var po = await LoadAsync(id);
        if (po.Status != PoStatus.Purchased)
            throw DomainException.Conflict($"P.O. is '{po.Status}'. Only purchased P.O.s can be received.");

        foreach (var line in po.PurchaseOrderItems)
        {
            line.Item.QtyOnHand += line.Qty;
            po.Ticket.TicketItems.First(t => t.TicketItemId == line.TicketItemId).QtyReceived += line.Qty;
            db.StockMovements.Add(new StockMovement
            {
                ItemId = line.ItemId,
                TicketId = po.TicketId,
                PurchaseOrderId = po.PurchaseOrderId,
                MovementType = MovementTypes.Receive,
                Qty = line.Qty,
                PerformedById = actor.UserId,
                CreatedAt = DateTime.UtcNow,
                Note = $"Received on {po.PoNo}"
            });
        }

        po.Status = PoStatus.Received;
        po.ReceivedAt = DateTime.UtcNow;

        await db.SaveChangesAsync();
        return await GetAsync(id);
    }

    // ---------- helpers ----------
    private async Task EnsureSupplierAsync(int supplierId)
    {
        var s = await db.Suppliers.FindAsync(supplierId)
                ?? throw DomainException.NotFound($"Supplier {supplierId} was not found.");
        if (!s.IsActive)
            throw DomainException.Conflict("This supplier is inactive.");
    }

    /// <summary>Adds the P.O. lines and reserves their quantities on the ticket's "to buy" lines.</summary>
    private static void ApplyLines(PurchaseOrder po, Ticket ticket, List<PoLineDto> lines)
    {
        if (lines.Count == 0)
            throw DomainException.BadRequest("A P.O. needs at least one line.");
        if (lines.Select(l => l.TicketItemId).Distinct().Count() != lines.Count)
            throw DomainException.BadRequest("Each ticket line may appear only once per P.O.");

        foreach (var l in lines)
        {
            var ti = ticket.TicketItems.FirstOrDefault(t => t.TicketItemId == l.TicketItemId)
                     ?? throw DomainException.BadRequest($"Ticket line {l.TicketItemId} does not belong to ticket {ticket.TicketNo}.");

            var remaining = ti.QtyToBuy - ti.QtyOrdered;
            if (l.Qty > remaining)
                throw DomainException.Conflict(
                    $"Ticket line {ti.TicketItemId} only has {remaining} left to order (needs {ti.QtyToBuy}, already on P.O.s: {ti.QtyOrdered}).");

            ti.QtyOrdered += l.Qty;
            po.PurchaseOrderItems.Add(new PurchaseOrderItem
            {
                TicketItemId = ti.TicketItemId,
                ItemId = ti.ItemId,
                Qty = l.Qty,
                UnitPrice = l.UnitPrice
            });
        }

        po.TotalAmount = po.PurchaseOrderItems.Sum(i => i.Qty * i.UnitPrice);
        RecomputeTicketStatus(ticket);
    }

    private static void UndoLines(PurchaseOrder po, Ticket ticket)
    {
        foreach (var line in po.PurchaseOrderItems)
            ticket.TicketItems.First(t => t.TicketItemId == line.TicketItemId).QtyOrdered -= line.Qty;
        RecomputeTicketStatus(ticket);
    }

    /// <summary>po_creation = nothing ordered, po_queue = partly ordered, po_created = everything to buy is on a P.O.</summary>
    private static void RecomputeTicketStatus(Ticket t)
    {
        if (t.Status is not (TicketStatus.PoCreation or TicketStatus.PoQueue or TicketStatus.PoCreated)) return;

        t.Status = t.TicketItems.Where(i => i.QtyToBuy > 0).All(i => i.QtyOrdered >= i.QtyToBuy) ? TicketStatus.PoCreated
                 : t.TicketItems.Any(i => i.QtyOrdered > 0) ? TicketStatus.PoQueue
                 : TicketStatus.PoCreation;
    }
}
