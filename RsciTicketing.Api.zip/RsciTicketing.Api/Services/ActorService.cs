namespace RsciTicketing.Api.Services;

/// <summary>Resolves the acting user and enforces the role rules from the operations doc. Admin passes every check.</summary>
public class ActorService(RsciDbContext db)
{
    public async Task<User> RequireAsync(int userId, params string[] roles)
    {
        var user = await db.Users.FindAsync(userId)
                   ?? throw DomainException.NotFound($"User {userId} was not found.");

        if (!user.IsActive)
            throw DomainException.Forbidden("This user account is inactive.");

        if (user.Role != Roles.Admin && !roles.Contains(user.Role))
            throw DomainException.Forbidden(
                $"Role '{user.Role}' cannot perform this action. Allowed: {string.Join(", ", roles)}.");

        return user;
    }
}
