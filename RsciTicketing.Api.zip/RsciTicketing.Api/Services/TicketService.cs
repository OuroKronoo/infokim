namespace RsciTicketing.Api.Services;

public class TicketService(RsciDbContext db, IMapper mapper, ActorService actors)
{
    private static readonly string[] Releasable =
        [TicketStatus.InventoryCheck, TicketStatus.PoCreation, TicketStatus.PoQueue, TicketStatus.PoCreated];

    /// <summary>
    /// The downpayment gate: the project's downpayment is Paid, the project is flagged NoBillingRequired,
    /// or the Boss granted an override on this ticket.
    /// </summary>
    public static bool GateClear(Project p, Ticket t) =>
        p.NoBillingRequired || p.DownpaymentStatus == DownpaymentStatus.Paid || t.OverrideApprovedById != null;

    // ---------- reads ----------
    public async Task<List<TicketDto>> ListAsync(string? status, int? projectId, int? requestedById)
    {
        var q = db.Tickets.AsNoTracking();
        if (!string.IsNullOrWhiteSpace(status)) q = q.Where(t => t.Status == status);
        if (projectId != null) q = q.Where(t => t.ProjectId == projectId);
        if (requestedById != null) q = q.Where(t => t.RequestedById == requestedById);

        return await q.OrderByDescending(t => t.CreatedAt)
                      .ProjectTo<TicketDto>(mapper.ConfigurationProvider)
                      .ToListAsync();
    }

    public async Task<TicketDto> GetAsync(int id) =>
        await db.Tickets.AsNoTracking().Where(t => t.TicketId == id)
                .ProjectTo<TicketDto>(mapper.ConfigurationProvider)
                .FirstOrDefaultAsync()
        ?? throw DomainException.NotFound($"Ticket {id} was not found.");

    private async Task<Ticket> LoadAsync(int id) =>
        await db.Tickets
                .Include(t => t.Project)
                .Include(t => t.TicketItems).ThenInclude(i => i.Item)
                .FirstOrDefaultAsync(t => t.TicketId == id)
        ?? throw DomainException.NotFound($"Ticket {id} was not found.");

    // ---------- create / update / delete (engineer) ----------
    public async Task<TicketDto> CreateAsync(CreateTicketDto dto)
    {
        await actors.RequireAsync(dto.RequestedById, Roles.Employee, Roles.OmInternal);

        if (!await db.Projects.AnyAsync(p => p.ProjectId == dto.ProjectId))
            throw DomainException.NotFound($"Project {dto.ProjectId} was not found.");
        if (dto.DateNeeded < DateOnly.FromDateTime(DateTime.Today))
            throw DomainException.BadRequest("Date Needed cannot be in the past.");
        await ValidateLinesAsync(dto.Items);

        var ticket = new Ticket
        {
            TicketNo = "TMP-" + Guid.NewGuid().ToString("N")[..12],
            ProjectId = dto.ProjectId,
            RequestedById = dto.RequestedById,
            Status = TicketStatus.BossApproval,   // every request goes to the Boss first
            Remarks = dto.Remarks,
            DateNeeded = dto.DateNeeded,
            CreatedAt = DateTime.UtcNow
        };
        foreach (var l in dto.Items)
            ticket.TicketItems.Add(new TicketItem { ItemId = l.ItemId, QtyRequested = l.Qty });

        db.Tickets.Add(ticket);
        await db.SaveChangesAsync();

        ticket.TicketNo = $"TKT-{ticket.CreatedAt:yyyy}-{ticket.TicketId:D5}";
        await db.SaveChangesAsync();
        return await GetAsync(ticket.TicketId);
    }

    public async Task<TicketDto> UpdateAsync(int id, UpdateTicketDto dto)
    {
        var actor = await actors.RequireAsync(dto.UserId, Roles.Employee, Roles.OmInternal);
        var t = await LoadAsync(id);
        EnsureOwner(t, actor);

        if (t.Status is not (TicketStatus.BossApproval or TicketStatus.BossRejected))
            throw DomainException.Conflict($"Ticket is '{t.Status}'. Only tickets waiting for (or rejected by) the Boss can be edited.");
        if (dto.DateNeeded < DateOnly.FromDateTime(DateTime.Today))
            throw DomainException.BadRequest("Date Needed cannot be in the past.");
        await ValidateLinesAsync(dto.Items);

        // Delete the old lines first (own save) so the (TicketId, ItemId) unique index never sees duplicates.
        await using var tx = await db.Database.BeginTransactionAsync();
        db.TicketItems.RemoveRange(t.TicketItems);
        await db.SaveChangesAsync();
        t.TicketItems.Clear();

        foreach (var l in dto.Items)
            t.TicketItems.Add(new TicketItem { ItemId = l.ItemId, QtyRequested = l.Qty });

        t.Remarks = dto.Remarks;
        t.DateNeeded = dto.DateNeeded;
        // Editing a rejected request resubmits it to the Boss.
        t.Status = TicketStatus.BossApproval;
        t.BossDecidedById = null; t.BossDecidedAt = null; t.DecisionNote = null;

        await db.SaveChangesAsync();
        await tx.CommitAsync();
        return await GetAsync(id);
    }

    public async Task DeleteAsync(int id, int userId)
    {
        var actor = await actors.RequireAsync(userId, Roles.Employee, Roles.OmInternal);
        var t = await LoadAsync(id);
        EnsureOwner(t, actor);

        if (t.Status is not (TicketStatus.BossApproval or TicketStatus.BossRejected))
            throw DomainException.Conflict("Only tickets that have not been approved can be deleted.");

        db.Tickets.Remove(t);
        await db.SaveChangesAsync();
    }

    // ---------- stage 1: Boss / OM ----------
    public async Task<TicketDto> ApproveAsync(int id, ActorDto dto)
    {
        var actor = await actors.RequireAsync(dto.UserId, Roles.Approvers);
        var t = await LoadAsync(id);
        if (t.Status != TicketStatus.BossApproval)
            throw DomainException.Conflict($"Ticket is '{t.Status}', not waiting for approval.");

        // Automatic inventory check: release = min(stock, requested), buy = the rest. No stock is deducted here.
        foreach (var line in t.TicketItems)
        {
            line.QtyFromStock = Math.Min(line.Item.QtyOnHand, line.QtyRequested);
            line.QtyToBuy = line.QtyRequested - line.QtyFromStock;
        }

        t.BossDecidedById = actor.UserId;
        t.BossDecidedAt = DateTime.UtcNow;
        t.DecisionNote = dto.Note;

        var needsPurchase = t.TicketItems.Any(i => i.QtyToBuy > 0);
        t.Status = !needsPurchase ? TicketStatus.InventoryCheck
                 : GateClear(t.Project, t) ? TicketStatus.PoCreation
                 : TicketStatus.PendingOverride;

        await db.SaveChangesAsync();
        return await GetAsync(id);
    }

    public async Task<TicketDto> RejectAsync(int id, ReasonDto dto)
    {
        var actor = await actors.RequireAsync(dto.UserId, Roles.Approvers);
        var t = await LoadAsync(id);
        if (t.Status != TicketStatus.BossApproval)
            throw DomainException.Conflict($"Ticket is '{t.Status}', not waiting for approval.");

        t.Status = TicketStatus.BossRejected;
        t.BossDecidedById = actor.UserId;
        t.BossDecidedAt = DateTime.UtcNow;
        t.DecisionNote = dto.Reason;

        await db.SaveChangesAsync();
        return await GetAsync(id);
    }

    // ---------- budget override: Boss only ----------
    public async Task<TicketDto> OverrideAsync(int id, ActorDto dto)
    {
        var actor = await actors.RequireAsync(dto.UserId, Roles.Boss);
        var t = await LoadAsync(id);
        if (t.Status is not (TicketStatus.PendingOverride or TicketStatus.InventoryCheck))
            throw DomainException.Conflict($"Ticket is '{t.Status}'; there is nothing to override.");

        t.OverrideApprovedById = actor.UserId;
        if (t.Status == TicketStatus.PendingOverride)
            t.Status = TicketStatus.PoCreation;

        await db.SaveChangesAsync();
        return await GetAsync(id);
    }

    // ---------- stock release: Inventory Manager ----------
    public async Task<TicketDto> ReleaseAsync(int id, ActorDto dto)
    {
        var actor = await actors.RequireAsync(dto.UserId, Roles.InventoryManager);
        var t = await LoadAsync(id);

        if (!Releasable.Contains(t.Status))
            throw DomainException.Conflict($"Ticket is '{t.Status}' and cannot release stock.");
        if (!GateClear(t.Project, t))
            throw DomainException.Conflict(
                "Stock release is locked: the project has no paid downpayment. " +
                "Ask the Boss for an override, or have Billing mark the downpayment as Paid.");

        var releasedAny = false;
        foreach (var line in t.TicketItems)
        {
            // Entitled = what came from stock at approval + what was delivered against a P.O., minus what already left.
            var entitled = line.QtyFromStock + line.QtyReceived - line.QtyReleased;
            var qty = Math.Min(Math.Max(entitled, 0), line.Item.QtyOnHand);
            if (qty <= 0) continue;

            line.Item.QtyOnHand -= qty;
            line.QtyReleased += qty;
            db.StockMovements.Add(new StockMovement
            {
                ItemId = line.ItemId,
                TicketId = t.TicketId,
                MovementType = MovementTypes.Release,
                Qty = qty,
                PerformedById = actor.UserId,
                CreatedAt = DateTime.UtcNow,
                Note = $"Released for {t.TicketNo}"
            });
            releasedAny = true;
        }

        if (!releasedAny)
            throw DomainException.Conflict("Nothing is available to release yet. Items still being purchased must be received first.");

        if (t.TicketItems.All(i => i.QtyReleased >= i.QtyRequested))
            t.Status = TicketStatus.Completed;

        await db.SaveChangesAsync();
        return await GetAsync(id);
    }

    // ---------- helpers ----------
    private static void EnsureOwner(Ticket t, User actor)
    {
        if (actor.Role != Roles.Admin && actor.UserId != t.RequestedById)
            throw DomainException.Forbidden("Only the engineer who filed the ticket can change it.");
    }

    private async Task ValidateLinesAsync(List<TicketLineDto> lines)
    {
        if (lines.Count == 0)
            throw DomainException.BadRequest("A ticket needs at least one material line.");

        var ids = lines.Select(l => l.ItemId).ToList();
        if (ids.Distinct().Count() != ids.Count)
            throw DomainException.BadRequest("Each material may appear only once per ticket.");

        var found = await db.InventoryItems.CountAsync(i => ids.Contains(i.ItemId));
        if (found != ids.Count)
            throw DomainException.BadRequest("One or more materials do not exist in the catalog.");
    }
}
