namespace RsciTicketing.Api.Models;

public partial class InventoryItem
{
    public int ItemId { get; set; }
    public string Sku { get; set; } = null!;
    public string Name { get; set; } = null!;
    public string Unit { get; set; } = null!;
    public int QtyOnHand { get; set; }
    public int ReorderLevel { get; set; }
    public decimal UnitCost { get; set; }
}
