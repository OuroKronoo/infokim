namespace RsciTicketing.Api.Models;

public partial class TicketItem
{
    public int TicketItemId { get; set; }
    public int TicketId { get; set; }
    public int ItemId { get; set; }
    public int QtyRequested { get; set; }
    public int QtyFromStock { get; set; }
    public int QtyToBuy { get; set; }
    public int QtyOrdered { get; set; }
    public int QtyReceived { get; set; }
    public int QtyReleased { get; set; }

    public virtual Ticket Ticket { get; set; } = null!;
    public virtual InventoryItem Item { get; set; } = null!;
    public virtual ICollection<PurchaseOrderItem> PurchaseOrderItems { get; set; } = new List<PurchaseOrderItem>();
}
