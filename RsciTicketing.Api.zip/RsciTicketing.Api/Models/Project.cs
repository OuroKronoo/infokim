namespace RsciTicketing.Api.Models;

public partial class Project
{
    public int ProjectId { get; set; }
    public string Name { get; set; } = null!;
    public string? ClientCompany { get; set; }
    public decimal? Budget { get; set; }
    public string DownpaymentStatus { get; set; } = null!;
    public bool NoBillingRequired { get; set; }

    public virtual ICollection<Ticket> Tickets { get; set; } = new List<Ticket>();
}
