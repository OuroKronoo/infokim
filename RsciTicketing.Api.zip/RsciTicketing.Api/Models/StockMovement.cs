namespace RsciTicketing.Api.Models;

public partial class StockMovement
{
    public int MovementId { get; set; }
    public int ItemId { get; set; }
    public int? TicketId { get; set; }
    public int? PurchaseOrderId { get; set; }
    public string MovementType { get; set; } = null!;
    public int Qty { get; set; }
    public int PerformedById { get; set; }
    public DateTime CreatedAt { get; set; }
    public string? Note { get; set; }

    public virtual InventoryItem Item { get; set; } = null!;
    public virtual User PerformedBy { get; set; } = null!;
}
