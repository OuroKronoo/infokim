namespace RsciTicketing.Api.Models;

public partial class PurchaseOrder
{
    public int PurchaseOrderId { get; set; }
    public string PoNo { get; set; } = null!;
    public int TicketId { get; set; }
    public int SupplierId { get; set; }
    public string Status { get; set; } = null!;
    public decimal TotalAmount { get; set; }
    public int CreatedById { get; set; }
    public DateTime CreatedAt { get; set; }
    public int? ApprovedById { get; set; }
    public DateTime? ApprovedAt { get; set; }
    public bool RushNoApproval { get; set; }
    public string? RushReason { get; set; }
    public string? RejectionReason { get; set; }
    public string? VoidReason { get; set; }
    public string? OrderOfPaymentNo { get; set; }
    public DateTime? PaymentReleasedAt { get; set; }
    public string? SiOrNo { get; set; }
    public DateTime? PurchasedAt { get; set; }
    public DateTime? ReceivedAt { get; set; }

    public virtual Ticket Ticket { get; set; } = null!;
    public virtual Supplier Supplier { get; set; } = null!;
    public virtual User CreatedBy { get; set; } = null!;
    public virtual User? ApprovedBy { get; set; }
    public virtual ICollection<PurchaseOrderItem> PurchaseOrderItems { get; set; } = new List<PurchaseOrderItem>();
}
