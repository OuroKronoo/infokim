namespace RsciTicketing.Api.Models;

public partial class PurchaseOrderItem
{
    public int PurchaseOrderItemId { get; set; }
    public int PurchaseOrderId { get; set; }
    public int TicketItemId { get; set; }
    public int ItemId { get; set; }
    public int Qty { get; set; }
    public decimal UnitPrice { get; set; }

    public virtual PurchaseOrder PurchaseOrder { get; set; } = null!;
    public virtual TicketItem TicketItem { get; set; } = null!;
    public virtual InventoryItem Item { get; set; } = null!;
}
