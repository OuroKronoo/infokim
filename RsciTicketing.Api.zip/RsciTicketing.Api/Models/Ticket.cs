namespace RsciTicketing.Api.Models;

public partial class Ticket
{
    public int TicketId { get; set; }
    public string TicketNo { get; set; } = null!;
    public int ProjectId { get; set; }
    public int RequestedById { get; set; }
    public string Status { get; set; } = null!;
    public string? Remarks { get; set; }
    public DateOnly DateNeeded { get; set; }
    public DateTime CreatedAt { get; set; }
    public int? BossDecidedById { get; set; }
    public DateTime? BossDecidedAt { get; set; }
    public string? DecisionNote { get; set; }
    public int? OverrideApprovedById { get; set; }

    public virtual Project Project { get; set; } = null!;
    public virtual User RequestedBy { get; set; } = null!;
    public virtual User? BossDecidedBy { get; set; }
    public virtual User? OverrideApprovedBy { get; set; }
    public virtual ICollection<TicketItem> TicketItems { get; set; } = new List<TicketItem>();
    public virtual ICollection<PurchaseOrder> PurchaseOrders { get; set; } = new List<PurchaseOrder>();
}
