namespace RsciTicketing.Api.Models;

public partial class Supplier
{
    public int SupplierId { get; set; }
    public string Name { get; set; } = null!;
    public string? ContactNo { get; set; }
    public bool IsActive { get; set; }

    public virtual ICollection<PurchaseOrder> PurchaseOrders { get; set; } = new List<PurchaseOrder>();
}
