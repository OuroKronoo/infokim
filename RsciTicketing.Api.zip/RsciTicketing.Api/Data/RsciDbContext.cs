namespace RsciTicketing.Api.Data;

public partial class RsciDbContext : DbContext
{
    public RsciDbContext(DbContextOptions<RsciDbContext> options) : base(options) { }

    public virtual DbSet<User> Users { get; set; }
    public virtual DbSet<Project> Projects { get; set; }
    public virtual DbSet<Supplier> Suppliers { get; set; }
    public virtual DbSet<InventoryItem> InventoryItems { get; set; }
    public virtual DbSet<Ticket> Tickets { get; set; }
    public virtual DbSet<TicketItem> TicketItems { get; set; }
    public virtual DbSet<PurchaseOrder> PurchaseOrders { get; set; }
    public virtual DbSet<PurchaseOrderItem> PurchaseOrderItems { get; set; }
    public virtual DbSet<StockMovement> StockMovements { get; set; }

    protected override void OnModelCreating(ModelBuilder mb)
    {
        mb.Entity<Project>().Property(p => p.Budget).HasColumnType("decimal(18, 2)");
        mb.Entity<InventoryItem>().Property(i => i.UnitCost).HasColumnType("decimal(18, 2)");
        mb.Entity<PurchaseOrder>().Property(p => p.TotalAmount).HasColumnType("decimal(18, 2)");
        mb.Entity<PurchaseOrderItem>().Property(p => p.UnitPrice).HasColumnType("decimal(18, 2)");

        mb.Entity<Ticket>(e =>
        {
            e.Property(t => t.DateNeeded).HasColumnType("date");
            e.HasOne(t => t.Project).WithMany(p => p.Tickets).HasForeignKey(t => t.ProjectId);
            e.HasOne(t => t.RequestedBy).WithMany().HasForeignKey(t => t.RequestedById);
            e.HasOne(t => t.BossDecidedBy).WithMany().HasForeignKey(t => t.BossDecidedById);
            e.HasOne(t => t.OverrideApprovedBy).WithMany().HasForeignKey(t => t.OverrideApprovedById);
        });

        mb.Entity<TicketItem>(e =>
        {
            e.HasOne(t => t.Ticket).WithMany(t => t.TicketItems).HasForeignKey(t => t.TicketId).OnDelete(DeleteBehavior.Cascade);
            e.HasOne(t => t.Item).WithMany().HasForeignKey(t => t.ItemId);
        });

        mb.Entity<PurchaseOrder>(e =>
        {
            e.HasOne(p => p.Ticket).WithMany(t => t.PurchaseOrders).HasForeignKey(p => p.TicketId);
            e.HasOne(p => p.Supplier).WithMany(s => s.PurchaseOrders).HasForeignKey(p => p.SupplierId);
            e.HasOne(p => p.CreatedBy).WithMany().HasForeignKey(p => p.CreatedById);
            e.HasOne(p => p.ApprovedBy).WithMany().HasForeignKey(p => p.ApprovedById);
        });

        mb.Entity<PurchaseOrderItem>(e =>
        {
            e.HasOne(p => p.PurchaseOrder).WithMany(p => p.PurchaseOrderItems).HasForeignKey(p => p.PurchaseOrderId).OnDelete(DeleteBehavior.Cascade);
            e.HasOne(p => p.TicketItem).WithMany(t => t.PurchaseOrderItems).HasForeignKey(p => p.TicketItemId);
            e.HasOne(p => p.Item).WithMany().HasForeignKey(p => p.ItemId);
        });

        mb.Entity<StockMovement>(e =>
        {
            e.HasOne(m => m.Item).WithMany().HasForeignKey(m => m.ItemId);
            e.HasOne(m => m.PerformedBy).WithMany().HasForeignKey(m => m.PerformedById);
        });
    }
}
