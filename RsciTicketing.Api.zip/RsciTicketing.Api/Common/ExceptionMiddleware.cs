namespace RsciTicketing.Api.Common;

public class ExceptionMiddleware(RequestDelegate next)
{
    public async Task InvokeAsync(HttpContext ctx)
    {
        try
        {
            await next(ctx);
        }
        catch (DomainException ex)
        {
            ctx.Response.StatusCode = ex.Status;
            await ctx.Response.WriteAsJsonAsync(new ProblemDetails
            {
                Status = ex.Status,
                Title = ex.Status switch
                {
                    400 => "Invalid request",
                    403 => "Not allowed for this role",
                    404 => "Not found",
                    409 => "Business rule violated",
                    _ => "Error"
                },
                Detail = ex.Message
            });
        }
    }
}
