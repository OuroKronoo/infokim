namespace RsciTicketing.Api.Common;

/// <summary>A business-rule violation. The middleware turns it into an HTTP ProblemDetails response.</summary>
public class DomainException(int status, string message) : Exception(message)
{
    public int Status { get; } = status;

    public static DomainException BadRequest(string m) => new(StatusCodes.Status400BadRequest, m);
    public static DomainException Forbidden(string m) => new(StatusCodes.Status403Forbidden, m);
    public static DomainException NotFound(string m) => new(StatusCodes.Status404NotFound, m);
    public static DomainException Conflict(string m) => new(StatusCodes.Status409Conflict, m);
}
