namespace RsciTicketing.Api.Common;

public static class Roles
{
    public const string Employee = "employee";
    public const string Boss = "boss";
    public const string Om = "om";
    public const string OmInternal = "om_internal";
    public const string OmExternal = "om_external";
    public const string InventoryManager = "inventory_manager";
    public const string PoOfficer = "po_officer";
    public const string Requisitor = "requisitor";
    public const string Accountant = "accountant";
    public const string BillingAccountant = "billing_accountant";
    public const string Admin = "admin";

    public static readonly string[] All =
    [
        Employee, Boss, Om, OmInternal, OmExternal, InventoryManager,
        PoOfficer, Requisitor, Accountant, BillingAccountant, Admin
    ];

    /// <summary>Boss + the three Operations Manager seats: they sign what the OM signs.</summary>
    public static readonly string[] Approvers = [Boss, Om, OmInternal, OmExternal];
}

public static class TicketStatus
{
    public const string BossApproval = "boss_approval";
    public const string BossRejected = "boss_rejected";
    public const string InventoryCheck = "inventory_check";
    public const string PoCreation = "po_creation";
    public const string PoQueue = "po_queue";
    public const string PoCreated = "po_created";
    public const string PendingOverride = "pending_override";
    public const string Completed = "completed";
    public const string PurchaseCancelled = "purchase_cancelled";
}

public static class PoStatus
{
    public const string PendingApproval = "PendingApproval";
    public const string Rejected = "Rejected";
    public const string Approved = "Approved";
    public const string AwaitingPaymentRelease = "AwaitingPaymentRelease";
    public const string PaymentReleased = "PaymentReleased";
    public const string Purchased = "Purchased";
    public const string Received = "Received";
    public const string Cancelled = "Cancelled";
}

public static class MovementTypes
{
    public const string StockIn = "StockIn";
    public const string Receive = "Receive";
    public const string Release = "Release";
}

public static class DownpaymentStatus
{
    public const string None = "None";
    public const string Invoiced = "Invoiced";
    public const string Paid = "Paid";
}
