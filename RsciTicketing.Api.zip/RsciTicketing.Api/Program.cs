using RsciTicketing.Api.Mapping;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddDbContext<RsciDbContext>(o =>
    o.UseSqlServer(builder.Configuration.GetConnectionString("RsciDb")));

builder.Services.AddAutoMapper(typeof(MappingProfile));

builder.Services.AddScoped<ActorService>();
builder.Services.AddScoped<TicketService>();
builder.Services.AddScoped<PurchaseOrderService>();

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

app.UseMiddleware<ExceptionMiddleware>();
app.UseSwagger();
app.UseSwaggerUI();
app.MapControllers();

app.Run();
