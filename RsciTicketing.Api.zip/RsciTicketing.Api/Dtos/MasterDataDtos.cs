using System.ComponentModel.DataAnnotations;

namespace RsciTicketing.Api.Dtos;

public class UserDto
{
    public int UserId { get; set; }
    public string FullName { get; set; } = "";
    public string Email { get; set; } = "";
    public string Role { get; set; } = "";
    public bool IsActive { get; set; }
}

public class CreateUserDto
{
    [Required, StringLength(100)] public string FullName { get; set; } = "";
    [Required, EmailAddress, StringLength(150)] public string Email { get; set; } = "";
    [Required] public string Role { get; set; } = "";
}

public class ProjectDto
{
    public int ProjectId { get; set; }
    public string Name { get; set; } = "";
    public string? ClientCompany { get; set; }
    public decimal? Budget { get; set; }
    public string DownpaymentStatus { get; set; } = "";
    public bool NoBillingRequired { get; set; }
}

/// <summary>Used for create and update. DownpaymentStatus is intentionally absent: only Billing can change it.</summary>
public class SaveProjectDto
{
    [Required, StringLength(150)] public string Name { get; set; } = "";
    [StringLength(150)] public string? ClientCompany { get; set; }
    [Range(typeof(decimal), "0", "1000000000000")] public decimal? Budget { get; set; }
    public bool NoBillingRequired { get; set; }
}

public class SupplierDto
{
    public int SupplierId { get; set; }
    public string Name { get; set; } = "";
    public string? ContactNo { get; set; }
    public bool IsActive { get; set; }
}

public class SaveSupplierDto
{
    [Required, StringLength(150)] public string Name { get; set; } = "";
    [StringLength(50)] public string? ContactNo { get; set; }
    public bool IsActive { get; set; } = true;
}

public class InventoryItemDto
{
    public int ItemId { get; set; }
    public string Sku { get; set; } = "";
    public string Name { get; set; } = "";
    public string Unit { get; set; } = "";
    public int QtyOnHand { get; set; }
    public int ReorderLevel { get; set; }
    public decimal UnitCost { get; set; }
    public bool IsLowStock { get; set; }
}

/// <summary>QtyOnHand is not editable here: stock only changes through stock-in, receive, and release.</summary>
public class SaveInventoryItemDto
{
    [Required, StringLength(40)] public string Sku { get; set; } = "";
    [Required, StringLength(150)] public string Name { get; set; } = "";
    [Required, StringLength(20)] public string Unit { get; set; } = "";
    [Range(0, 1_000_000)] public int ReorderLevel { get; set; }
    [Range(typeof(decimal), "0", "1000000000")] public decimal UnitCost { get; set; }
}

public class StockMovementDto
{
    public int MovementId { get; set; }
    public int ItemId { get; set; }
    public string ItemName { get; set; } = "";
    public int? TicketId { get; set; }
    public int? PurchaseOrderId { get; set; }
    public string MovementType { get; set; } = "";
    public int Qty { get; set; }
    public string PerformedByName { get; set; } = "";
    public DateTime CreatedAt { get; set; }
    public string? Note { get; set; }
}
