using System.ComponentModel.DataAnnotations;

namespace RsciTicketing.Api.Dtos;

/// <summary>Who is performing the action. (Real auth is out of scope; the role check uses this user's Role.)</summary>
public class ActorDto
{
    [Range(1, int.MaxValue)] public int UserId { get; set; }
    [StringLength(500)] public string? Note { get; set; }
}

public class ReasonDto
{
    [Range(1, int.MaxValue)] public int UserId { get; set; }
    [Required, StringLength(300)] public string Reason { get; set; } = "";
}

public class ConfirmPurchasedDto
{
    [Range(1, int.MaxValue)] public int UserId { get; set; }
    [Required, StringLength(50)] public string SiOrNo { get; set; } = "";
}

public class StockInDto
{
    [Range(1, int.MaxValue)] public int UserId { get; set; }
    [Range(1, 1_000_000)] public int Qty { get; set; }
    [StringLength(300)] public string? Note { get; set; }
}
