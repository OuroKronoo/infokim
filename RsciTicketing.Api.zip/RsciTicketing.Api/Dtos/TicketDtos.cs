using System.ComponentModel.DataAnnotations;

namespace RsciTicketing.Api.Dtos;

public class TicketItemDto
{
    public int TicketItemId { get; set; }
    public int ItemId { get; set; }
    public string ItemName { get; set; } = "";
    public string Unit { get; set; } = "";
    public int QtyRequested { get; set; }
    public int QtyFromStock { get; set; }
    public int QtyToBuy { get; set; }
    public int QtyOrdered { get; set; }
    public int QtyReceived { get; set; }
    public int QtyReleased { get; set; }
}

public class TicketDto
{
    public int TicketId { get; set; }
    public string TicketNo { get; set; } = "";
    public int ProjectId { get; set; }
    public string ProjectName { get; set; } = "";
    public int RequestedById { get; set; }
    public string RequestedByName { get; set; } = "";
    public string Status { get; set; } = "";
    public string? Remarks { get; set; }
    public DateOnly DateNeeded { get; set; }
    public DateTime CreatedAt { get; set; }
    public string? DecisionNote { get; set; }
    public bool OverrideApproved { get; set; }
    public List<TicketItemDto> Items { get; set; } = new();
}

public class TicketLineDto
{
    [Range(1, int.MaxValue)] public int ItemId { get; set; }
    [Range(1, 1_000_000)] public int Qty { get; set; }
}

public class CreateTicketDto
{
    [Range(1, int.MaxValue)] public int ProjectId { get; set; }
    [Range(1, int.MaxValue)] public int RequestedById { get; set; }
    [StringLength(500)] public string? Remarks { get; set; }
    public DateOnly DateNeeded { get; set; }
    [Required, MinLength(1)] public List<TicketLineDto> Items { get; set; } = new();
}

public class UpdateTicketDto
{
    [Range(1, int.MaxValue)] public int UserId { get; set; }
    [StringLength(500)] public string? Remarks { get; set; }
    public DateOnly DateNeeded { get; set; }
    [Required, MinLength(1)] public List<TicketLineDto> Items { get; set; } = new();
}
