using System.ComponentModel.DataAnnotations;

namespace RsciTicketing.Api.Dtos;

public class PurchaseOrderItemDto
{
    public int PurchaseOrderItemId { get; set; }
    public int TicketItemId { get; set; }
    public int ItemId { get; set; }
    public string ItemName { get; set; } = "";
    public int Qty { get; set; }
    public decimal UnitPrice { get; set; }
    public decimal LineTotal { get; set; }
}

public class PurchaseOrderDto
{
    public int PurchaseOrderId { get; set; }
    public string PoNo { get; set; } = "";
    public int TicketId { get; set; }
    public string TicketNo { get; set; } = "";
    public int SupplierId { get; set; }
    public string SupplierName { get; set; } = "";
    public string Status { get; set; } = "";
    public decimal TotalAmount { get; set; }
    public string CreatedByName { get; set; } = "";
    public DateTime CreatedAt { get; set; }
    public DateTime? ApprovedAt { get; set; }
    public bool RushNoApproval { get; set; }
    public string? RushReason { get; set; }
    public string? RejectionReason { get; set; }
    public string? VoidReason { get; set; }
    public string? OrderOfPaymentNo { get; set; }
    public DateTime? PaymentReleasedAt { get; set; }
    public string? SiOrNo { get; set; }
    public DateTime? PurchasedAt { get; set; }
    public DateTime? ReceivedAt { get; set; }
    public List<PurchaseOrderItemDto> Items { get; set; } = new();
}

public class PoLineDto
{
    [Range(1, int.MaxValue)] public int TicketItemId { get; set; }
    [Range(1, 1_000_000)] public int Qty { get; set; }
    [Range(typeof(decimal), "0.01", "1000000000")] public decimal UnitPrice { get; set; }
}

public class CreatePurchaseOrderDto
{
    [Range(1, int.MaxValue)] public int TicketId { get; set; }
    [Range(1, int.MaxValue)] public int SupplierId { get; set; }
    [Range(1, int.MaxValue)] public int CreatedById { get; set; }
    [Required, MinLength(1)] public List<PoLineDto> Items { get; set; } = new();
}

public class UpdatePurchaseOrderDto
{
    [Range(1, int.MaxValue)] public int UserId { get; set; }
    [Range(1, int.MaxValue)] public int SupplierId { get; set; }
    [Required, MinLength(1)] public List<PoLineDto> Items { get; set; } = new();
}
