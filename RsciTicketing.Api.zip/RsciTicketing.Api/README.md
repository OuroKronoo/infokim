# RSCI Ticketing API

Backend API for the **RSCI Ticketing** material-request system: an engineer requests materials for a project, the Boss approves,
Inventory checks stock, the PO Officer buys what is missing, Accounting pays, Inventory receives and releases to the project.

ASP.NET Core 8 Web API · **Database First** · EF Core · DTOs · AutoMapper · model binding + validation · Swagger.

## 1. Run it

1. **Create the database** (SQL Server / LocalDB): run `Database/schema.sql`. It creates the tables and seeds 9 users (one per role), 3 projects, 2 suppliers, 6 items.
2. **Scaffold the models** (this is the Database-First step; it regenerates `Models/` and `Data/RsciDbContext.cs`):
   ```
   dotnet tool install --global dotnet-ef
   dotnet ef dbcontext scaffold "Server=localhost;Database=RsciTicketing;Trusted_Connection=True;TrustServerCertificate=True" Microsoft.EntityFrameworkCore.SqlServer --output-dir Models --context-dir Data --context RsciDbContext --namespace RsciTicketing.Api.Models --context-namespace RsciTicketing.Api.Data --no-onconfiguring --force
   ```
   The files already in `Models/` and `Data/` were written to match what scaffolding produces, so the project also runs without this step. Do it anyway so you can say (and show) that the entities came from the database.
3. Set the connection string in `appsettings.json`, then `dotnet run` and open `/swagger`.
4. Follow the demo in `RsciTicketing.Api.http` (or Swagger).

## 1b. Running in Visual Studio 2022

Needs Visual Studio 2022 with the **ASP.NET and web development** workload (.NET 8 SDK) and SQL Server / LocalDB (installed with the "Data storage and processing" workload).

1. Open `RsciTicketing.Api.sln`. Visual Studio restores the NuGet packages automatically.
2. Open **View > SQL Server Object Explorer**, connect to `(localdb)\MSSQLLocalDB`, then open `Database/schema.sql`, connect, and run it. For LocalDB use this connection string in `appsettings.json`:
   `Server=(localdb)\MSSQLLocalDB;Database=RsciTicketing;Trusted_Connection=True;TrustServerCertificate=True`
3. Scaffold (Database First): **Tools > NuGet Package Manager > Package Manager Console**, with the project selected, run:
   ```
   Scaffold-DbContext "Server=(localdb)\MSSQLLocalDB;Database=RsciTicketing;Trusted_Connection=True;TrustServerCertificate=True" Microsoft.EntityFrameworkCore.SqlServer -OutputDir Models -ContextDir Data -Context RsciDbContext -Namespace RsciTicketing.Api.Models -ContextNamespace RsciTicketing.Api.Data -NoOnConfiguring -Force
   ```
4. Press **F5**. Swagger opens at `https://localhost:7000/swagger`.
5. `RsciTicketing.Api.http` runs inside Visual Studio 2022 17.8+ (open it and click the green arrow next to each request).

## 2. Architecture

```
Request JSON -> Controller (model binding + DataAnnotations -> 400)
             -> Service (business rules, role check -> 403/404/409)
             -> EF Core (RsciDbContext, scaffolded from SQL Server)
             -> AutoMapper (Entity -> DTO, ProjectTo for reads)
             -> Response DTO
```

| Layer | Folder | Notes |
|---|---|---|
| Database | `Database/schema.sql` | PKs, FKs, CHECK constraints for statuses, UNIQUE constraints |
| Entities + DbContext | `Models/`, `Data/` | Scaffolded, never returned from an endpoint |
| DTOs | `Dtos/` | Separate create/update/response shapes; validation attributes |
| AutoMapper | `Mapping/MappingProfile.cs` | One profile for every mapping |
| Rules | `Services/` | `TicketService`, `PurchaseOrderService`, `ActorService` (role checks) |
| API | `Controllers/` | Thin controllers, REST verbs and status codes |
| Errors | `Common/ExceptionMiddleware.cs` | `DomainException` becomes ProblemDetails (400/403/404/409) |

There is no login: every action carries the acting `userId` in the body (or query for DELETE), and the service checks that user's `Role`. `admin` passes every role check.

## 3. ERD

```mermaid
erDiagram
    Users ||--o{ Tickets : requests
    Projects ||--o{ Tickets : "charged to"
    Tickets ||--|{ TicketItems : contains
    InventoryItems ||--o{ TicketItems : "requested as"
    Tickets ||--o{ PurchaseOrders : "bought via"
    Suppliers ||--o{ PurchaseOrders : supplies
    PurchaseOrders ||--|{ PurchaseOrderItems : contains
    TicketItems ||--o{ PurchaseOrderItems : "ordered as"
    InventoryItems ||--o{ StockMovements : "logged in"
    Users ||--o{ StockMovements : performs
```

## 4. Use cases (Actor / Scenario / Fields / Rule / API / Result)

| Actor | Scenario | Fields | Business rule | API | Result |
|---|---|---|---|---|---|
| Engineer | Needs materials for a site | `Tickets.DateNeeded`, `TicketItems.QtyRequested` | Role employee/om_internal; date not in the past; at least one line; no duplicate material | `POST /api/tickets` | `201`, status `boss_approval` |
| Boss / OM | Reviews a request | `Status`, `QtyFromStock`, `QtyToBuy` | Only from `boss_approval`. Approval runs the stock check: `fromStock = min(stock, requested)`, rest is to buy. Nothing is deducted yet | `POST /api/tickets/{id}/approve` | `po_creation` (buy needed), `inventory_check` (all in stock) or `pending_override` (gate closed) |
| Boss | Project has no downpayment | `OverrideApprovedById` | Override is **Boss-only** (OM gets 403) | `POST /api/tickets/{id}/override` | Ticket returns to `po_creation` |
| Billing | Client paid the downpayment | `Projects.DownpaymentStatus` | Billing only; every waiting ticket of that project leaves `pending_override` | `POST /api/projects/{id}/downpayment/paid` | Project `Paid`, tickets unlocked |
| PO Officer | Buys the missing items | `PurchaseOrderItems.Qty/UnitPrice` | Can't order more than `QtyToBuy - QtyOrdered`; several P.O.s per ticket allowed; supplier must be active | `POST /api/purchase-orders` | `201`, `PendingApproval`, ticket `po_queue`/`po_created` |
| Boss / OM | Signs a P.O. | `Status`, `ApprovedById` | Either one clears it; rejected P.O. can be edited (resubmits) or voided | `POST /api/purchase-orders/{id}/approve` | `Approved` |
| PO Officer | Urgent buy, no time for approval | `RushNoApproval`, `RushReason` | Reason mandatory; flagged so it is never mistaken for a real approval; Boss/OM can still reject before payment | `POST /api/purchase-orders/{id}/rush` | `Approved` with rush flag |
| Accountant, Boss | Payment chain | `OrderOfPaymentNo`, `SiOrNo` | Strict order: Approved -> O.P. (accountant) -> release (Boss) -> confirm purchased with SI/OR (accountant) | `.../order-of-payment`, `.../release-payment`, `.../confirm-purchased` | `AwaitingPaymentRelease` -> `PaymentReleased` -> `Purchased` |
| Inventory | Delivery arrives | `QtyReceived`, `StockMovements` | Only `Purchased` P.O.s; adds stock and writes a `Receive` log entry | `POST /api/purchase-orders/{id}/receive` | `Received`, stock up |
| Inventory | Releases to the project | `QtyReleased`, `QtyOnHand` | **Gate:** downpayment Paid, `NoBillingRequired`, or Boss override, else `409`. Releases only what is entitled and in stock | `POST /api/tickets/{id}/release` | Stock deducted, log written, `completed` when fully released |
| PO Officer | Wrong P.O. | `VoidReason` | No hard delete; reason mandatory; not allowed after payment is released; quantities go back to the ticket | `DELETE /api/purchase-orders/{id}?userId=&reason=` | `Cancelled` |

## 5. Endpoints

| Resource | Endpoints |
|---|---|
| Users | `GET /api/users`, `GET /api/users/{id}`, `POST /api/users` |
| Projects | `GET`, `GET /{id}`, `POST`, `PUT /{id}`, `DELETE /{id}`, `POST /{id}/downpayment/paid` |
| Suppliers | `GET`, `GET /{id}`, `POST`, `PUT /{id}`, `DELETE /{id}` |
| Inventory items | `GET`, `GET /low-stock`, `GET /{id}`, `POST`, `PUT /{id}`, `DELETE /{id}`, `POST /{id}/stock-in` |
| Tickets | `GET` (filter by status, project, requester), `GET /{id}`, `POST`, `PUT /{id}`, `DELETE /{id}`, `POST /{id}/approve`, `/reject`, `/override`, `/release` |
| Purchase orders | `GET`, `GET /{id}`, `POST`, `PUT /{id}`, `DELETE /{id}` (void), `POST /{id}/approve`, `/reject`, `/rush`, `/order-of-payment`, `/release-payment`, `/confirm-purchased`, `/receive` |
| Stock movements | `GET` (filter by item, ticket, type) |

## 6. Ticket and P.O. lifecycles

```
Ticket: boss_approval -> boss_rejected (edit resubmits)
                      -> inventory_check (all in stock)
                      -> po_creation / pending_override -> po_queue -> po_created -> completed
P.O.:   PendingApproval -> Rejected (edit resubmits) | Approved -> AwaitingPaymentRelease
        -> PaymentReleased -> Purchased -> Received          (Cancelled = void, before payment release)
```

## 7. Deliberately simplified versus the live Firebase app

Mention these when presenting so nobody thinks they were missed:
Customer Billing and Order of Payment pages, General Expenses posting, EWT/check details, Tools & Equipment QR custody, Return/Pull-Out, Activity Log, notifications, requested items that are not in the catalog, the `po_item_locks` collection (replaced by the per-line `QtyReceived`/`QtyReleased` counters), and real authentication (the acting user is passed in the request). Stock changes are not protected against two people releasing at the same instant; add a `rowversion` column on `InventoryItems` if you want optimistic concurrency.

## 8. Mapping to the midterm PPT

| PPT requirement | Where |
|---|---|
| Database-first, EF Core | `Database/schema.sql` -> `dotnet ef dbcontext scaffold` -> `Data/RsciDbContext.cs` |
| DTOs | `Dtos/` (entities never leave the API) |
| AutoMapper | `Mapping/MappingProfile.cs`, `ProjectTo<>` in reads, `Map` in writes |
| Model binding / validation | `[ApiController]` + DataAnnotations on DTOs, `[FromQuery]`, `[FromBody]` |
| RESTful CRUD | Projects, Suppliers, Inventory items, Tickets, Purchase orders |
| Real rules, statuses, dates | Section 4 and 6 |
| Swagger demo | `/swagger` and `RsciTicketing.Api.http` |
