/* RSCI Ticketing - database-first schema (SQL Server). Run this FIRST, then scaffold with EF Core. */
IF DB_ID('RsciTicketing') IS NULL CREATE DATABASE RsciTicketing;
GO
USE RsciTicketing;
GO

CREATE TABLE Users (
    UserId   INT IDENTITY(1,1) PRIMARY KEY,
    FullName NVARCHAR(100) NOT NULL,
    Email    NVARCHAR(150) NOT NULL UNIQUE,
    Role     VARCHAR(30)   NOT NULL,
    IsActive BIT           NOT NULL DEFAULT 1,
    CONSTRAINT CK_Users_Role CHECK (Role IN ('employee','boss','om','om_internal','om_external',
        'inventory_manager','po_officer','requisitor','accountant','billing_accountant','admin'))
);

CREATE TABLE Projects (
    ProjectId         INT IDENTITY(1,1) PRIMARY KEY,
    Name              NVARCHAR(150) NOT NULL UNIQUE,
    ClientCompany     NVARCHAR(150) NULL,
    Budget            DECIMAL(18,2) NULL,
    DownpaymentStatus VARCHAR(15)   NOT NULL DEFAULT 'None',
    NoBillingRequired BIT           NOT NULL DEFAULT 0,
    CONSTRAINT CK_Projects_Budget CHECK (Budget IS NULL OR Budget >= 0),
    CONSTRAINT CK_Projects_Downpayment CHECK (DownpaymentStatus IN ('None','Invoiced','Paid'))
);

CREATE TABLE Suppliers (
    SupplierId INT IDENTITY(1,1) PRIMARY KEY,
    Name       NVARCHAR(150) NOT NULL UNIQUE,
    ContactNo  NVARCHAR(50)  NULL,
    IsActive   BIT           NOT NULL DEFAULT 1
);

CREATE TABLE InventoryItems (
    ItemId       INT IDENTITY(1,1) PRIMARY KEY,
    Sku          VARCHAR(40)   NOT NULL UNIQUE,
    Name         NVARCHAR(150) NOT NULL,
    Unit         VARCHAR(20)   NOT NULL,
    QtyOnHand    INT           NOT NULL DEFAULT 0,
    ReorderLevel INT           NOT NULL DEFAULT 0,
    UnitCost     DECIMAL(18,2) NOT NULL DEFAULT 0,
    CONSTRAINT CK_Items_Qty CHECK (QtyOnHand >= 0 AND ReorderLevel >= 0 AND UnitCost >= 0)
);

CREATE TABLE Tickets (
    TicketId           INT IDENTITY(1,1) PRIMARY KEY,
    TicketNo           VARCHAR(30)   NOT NULL UNIQUE,
    ProjectId          INT           NOT NULL REFERENCES Projects(ProjectId),
    RequestedById      INT           NOT NULL REFERENCES Users(UserId),
    Status             VARCHAR(30)   NOT NULL DEFAULT 'boss_approval',
    Remarks            NVARCHAR(500) NULL,
    DateNeeded         DATE          NOT NULL,
    CreatedAt          DATETIME2     NOT NULL DEFAULT SYSUTCDATETIME(),
    BossDecidedById    INT           NULL REFERENCES Users(UserId),
    BossDecidedAt      DATETIME2     NULL,
    DecisionNote       NVARCHAR(500) NULL,
    OverrideApprovedById INT         NULL REFERENCES Users(UserId),
    CONSTRAINT CK_Tickets_Status CHECK (Status IN ('boss_approval','boss_rejected','inventory_check',
        'po_creation','po_queue','po_created','pending_override','completed','purchase_cancelled'))
);

CREATE TABLE TicketItems (
    TicketItemId INT IDENTITY(1,1) PRIMARY KEY,
    TicketId     INT NOT NULL REFERENCES Tickets(TicketId) ON DELETE CASCADE,
    ItemId       INT NOT NULL REFERENCES InventoryItems(ItemId),
    QtyRequested INT NOT NULL,
    QtyFromStock INT NOT NULL DEFAULT 0,
    QtyToBuy     INT NOT NULL DEFAULT 0,
    QtyOrdered   INT NOT NULL DEFAULT 0,
    QtyReceived  INT NOT NULL DEFAULT 0,
    QtyReleased  INT NOT NULL DEFAULT 0,
    CONSTRAINT UQ_TicketItems UNIQUE (TicketId, ItemId),
    CONSTRAINT CK_TicketItems_Qty CHECK (QtyRequested > 0 AND QtyFromStock >= 0 AND QtyToBuy >= 0
        AND QtyOrdered >= 0 AND QtyReceived >= 0 AND QtyReleased >= 0)
);

CREATE TABLE PurchaseOrders (
    PurchaseOrderId    INT IDENTITY(1,1) PRIMARY KEY,
    PoNo               VARCHAR(30)   NOT NULL UNIQUE,
    TicketId           INT           NOT NULL REFERENCES Tickets(TicketId),
    SupplierId         INT           NOT NULL REFERENCES Suppliers(SupplierId),
    Status             VARCHAR(30)   NOT NULL DEFAULT 'PendingApproval',
    TotalAmount        DECIMAL(18,2) NOT NULL DEFAULT 0,
    CreatedById        INT           NOT NULL REFERENCES Users(UserId),
    CreatedAt          DATETIME2     NOT NULL DEFAULT SYSUTCDATETIME(),
    ApprovedById       INT           NULL REFERENCES Users(UserId),
    ApprovedAt         DATETIME2     NULL,
    RushNoApproval     BIT           NOT NULL DEFAULT 0,
    RushReason         NVARCHAR(300) NULL,
    RejectionReason    NVARCHAR(300) NULL,
    VoidReason         NVARCHAR(300) NULL,
    OrderOfPaymentNo   VARCHAR(30)   NULL,
    PaymentReleasedAt  DATETIME2     NULL,
    SiOrNo             VARCHAR(50)   NULL,
    PurchasedAt        DATETIME2     NULL,
    ReceivedAt         DATETIME2     NULL,
    CONSTRAINT CK_PO_Status CHECK (Status IN ('PendingApproval','Rejected','Approved','AwaitingPaymentRelease',
        'PaymentReleased','Purchased','Received','Cancelled'))
);

CREATE TABLE PurchaseOrderItems (
    PurchaseOrderItemId INT IDENTITY(1,1) PRIMARY KEY,
    PurchaseOrderId     INT NOT NULL REFERENCES PurchaseOrders(PurchaseOrderId) ON DELETE CASCADE,
    TicketItemId        INT NOT NULL REFERENCES TicketItems(TicketItemId),
    ItemId              INT NOT NULL REFERENCES InventoryItems(ItemId),
    Qty                 INT NOT NULL,
    UnitPrice           DECIMAL(18,2) NOT NULL,
    CONSTRAINT CK_POItems CHECK (Qty > 0 AND UnitPrice > 0)
);

/* Append-only stock history (inventory_log in the Firebase app). */
CREATE TABLE StockMovements (
    MovementId      INT IDENTITY(1,1) PRIMARY KEY,
    ItemId          INT          NOT NULL REFERENCES InventoryItems(ItemId),
    TicketId        INT          NULL REFERENCES Tickets(TicketId),
    PurchaseOrderId INT          NULL REFERENCES PurchaseOrders(PurchaseOrderId),
    MovementType    VARCHAR(15)  NOT NULL,
    Qty             INT          NOT NULL,
    PerformedById   INT          NOT NULL REFERENCES Users(UserId),
    CreatedAt       DATETIME2    NOT NULL DEFAULT SYSUTCDATETIME(),
    Note            NVARCHAR(300) NULL,
    CONSTRAINT CK_Movement_Type CHECK (MovementType IN ('StockIn','Receive','Release')),
    CONSTRAINT CK_Movement_Qty CHECK (Qty > 0)
);
GO

/* ---------------- Seed data ---------------- */
INSERT INTO Users (FullName, Email, Role) VALUES
 (N'Ana Reyes (Engineer)',   'ana@rsci.test',      'employee'),            -- 1
 (N'Bong Santos (Boss)',     'boss@rsci.test',     'boss'),                -- 2
 (N'Olivia Cruz (OM)',       'om@rsci.test',       'om'),                  -- 3
 (N'Ivan Lopez (Inventory)', 'inventory@rsci.test','inventory_manager'),   -- 4
 (N'Paolo Tan (PO Officer)', 'po@rsci.test',       'po_officer'),          -- 5
 (N'Rina Diaz (Requisitor)', 'req@rsci.test',      'requisitor'),          -- 6
 (N'Alma Gomez (Accountant)','acct@rsci.test',     'accountant'),          -- 7
 (N'Bea Lim (Billing)',      'billing@rsci.test',  'billing_accountant'),  -- 8
 (N'Admin User',             'admin@rsci.test',    'admin');               -- 9

INSERT INTO Projects (Name, ClientCompany, Budget, DownpaymentStatus, NoBillingRequired) VALUES
 (N'Warehouse Fit-out',      N'Northgate Corp', 500000, 'Paid', 0),        -- 1 gate clear
 (N'Office Renovation',      N'Harbor Holdings', NULL,  'None', 0),        -- 2 needs override
 (N'Internal Maintenance',   NULL,               NULL,  'None', 1);        -- 3 no billing required

INSERT INTO Suppliers (Name, ContactNo) VALUES (N'BuildMart Trading','0917-000-1111'),(N'Metro Hardware','0917-000-2222');

INSERT INTO InventoryItems (Sku, Name, Unit, QtyOnHand, ReorderLevel, UnitCost) VALUES
 ('CEM-40',  N'Portland Cement 40kg', 'bag',  100, 20, 260),   -- 1
 ('PNT-4L',  N'White Paint 4L',       'can',    0,  5, 780),   -- 2
 ('PVC-12',  N'PVC Pipe 1/2in',       'pc',    50, 10,  95),   -- 3
 ('WIR-35',  N'Electrical Wire 3.5mm','roll',   5,  3, 2100),  -- 4
 ('HAM-01',  N'Claw Hammer',          'pc',     3,  2, 320),   -- 5
 ('HLM-01',  N'Safety Helmet',        'pc',    20,  5, 250);   -- 6
GO
