namespace RsciTicketing.Api.Controllers;

[ApiController]
[Route("api/inventory-items")]
public class InventoryItemsController(RsciDbContext db, IMapper mapper, ActorService actors) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<List<InventoryItemDto>>> GetAll([FromQuery] string? search) =>
        await db.InventoryItems.AsNoTracking()
                .Where(i => search == null || i.Name.Contains(search) || i.Sku.Contains(search))
                .OrderBy(i => i.Name)
                .ProjectTo<InventoryItemDto>(mapper.ConfigurationProvider).ToListAsync();

    [HttpGet("low-stock")]
    public async Task<ActionResult<List<InventoryItemDto>>> LowStock() =>
        await db.InventoryItems.AsNoTracking()
                .Where(i => i.QtyOnHand <= i.ReorderLevel)
                .OrderBy(i => i.QtyOnHand)
                .ProjectTo<InventoryItemDto>(mapper.ConfigurationProvider).ToListAsync();

    [HttpGet("{id:int}")]
    public async Task<ActionResult<InventoryItemDto>> GetById(int id)
    {
        var dto = await db.InventoryItems.AsNoTracking().Where(i => i.ItemId == id)
                          .ProjectTo<InventoryItemDto>(mapper.ConfigurationProvider).FirstOrDefaultAsync();
        return dto is null ? NotFound() : dto;
    }

    [HttpPost]
    public async Task<ActionResult<InventoryItemDto>> Create(SaveInventoryItemDto dto)
    {
        if (await db.InventoryItems.AnyAsync(i => i.Sku == dto.Sku))
            return Conflict($"SKU '{dto.Sku}' already exists.");

        var entity = mapper.Map<InventoryItem>(dto);   // QtyOnHand starts at 0; use stock-in to add stock
        db.InventoryItems.Add(entity);
        await db.SaveChangesAsync();
        return CreatedAtAction(nameof(GetById), new { id = entity.ItemId }, mapper.Map<InventoryItemDto>(entity));
    }

    [HttpPut("{id:int}")]
    public async Task<ActionResult<InventoryItemDto>> Update(int id, SaveInventoryItemDto dto)
    {
        var entity = await db.InventoryItems.FindAsync(id);
        if (entity is null) return NotFound();
        if (await db.InventoryItems.AnyAsync(i => i.Sku == dto.Sku && i.ItemId != id))
            return Conflict($"SKU '{dto.Sku}' already exists.");

        mapper.Map(dto, entity);
        await db.SaveChangesAsync();
        return mapper.Map<InventoryItemDto>(entity);
    }

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Delete(int id)
    {
        var entity = await db.InventoryItems.FindAsync(id);
        if (entity is null) return NotFound();
        if (await db.TicketItems.AnyAsync(t => t.ItemId == id) || await db.StockMovements.AnyAsync(m => m.ItemId == id))
            return Conflict("This item is used by tickets or has stock history, so it cannot be deleted.");

        db.InventoryItems.Remove(entity);
        await db.SaveChangesAsync();
        return NoContent();
    }

    /// <summary>Manual stock-in by the Inventory Manager. Writes an entry in the movement log.</summary>
    [HttpPost("{id:int}/stock-in")]
    public async Task<ActionResult<InventoryItemDto>> StockIn(int id, StockInDto dto)
    {
        var actor = await actors.RequireAsync(dto.UserId, Roles.InventoryManager);
        var entity = await db.InventoryItems.FindAsync(id);
        if (entity is null) return NotFound();

        entity.QtyOnHand += dto.Qty;
        db.StockMovements.Add(new StockMovement
        {
            ItemId = id,
            MovementType = MovementTypes.StockIn,
            Qty = dto.Qty,
            PerformedById = actor.UserId,
            CreatedAt = DateTime.UtcNow,
            Note = dto.Note
        });
        await db.SaveChangesAsync();
        return mapper.Map<InventoryItemDto>(entity);
    }
}
