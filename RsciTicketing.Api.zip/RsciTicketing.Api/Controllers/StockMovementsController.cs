namespace RsciTicketing.Api.Controllers;

/// <summary>Read-only movement log. Entries are only ever written by stock-in, receive, and release.</summary>
[ApiController]
[Route("api/stock-movements")]
public class StockMovementsController(RsciDbContext db, IMapper mapper) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<List<StockMovementDto>>> GetAll(
        [FromQuery] int? itemId, [FromQuery] int? ticketId, [FromQuery] string? type) =>
        await db.StockMovements.AsNoTracking()
                .Where(m => (itemId == null || m.ItemId == itemId)
                         && (ticketId == null || m.TicketId == ticketId)
                         && (type == null || m.MovementType == type))
                .OrderByDescending(m => m.CreatedAt)
                .ProjectTo<StockMovementDto>(mapper.ConfigurationProvider).ToListAsync();
}
