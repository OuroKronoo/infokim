namespace RsciTicketing.Api.Controllers;

[ApiController]
[Route("api/suppliers")]
public class SuppliersController(RsciDbContext db, IMapper mapper) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<List<SupplierDto>>> GetAll([FromQuery] bool activeOnly = false) =>
        await db.Suppliers.AsNoTracking()
                .Where(s => !activeOnly || s.IsActive)
                .OrderBy(s => s.Name)
                .ProjectTo<SupplierDto>(mapper.ConfigurationProvider).ToListAsync();

    [HttpGet("{id:int}")]
    public async Task<ActionResult<SupplierDto>> GetById(int id)
    {
        var dto = await db.Suppliers.AsNoTracking().Where(s => s.SupplierId == id)
                          .ProjectTo<SupplierDto>(mapper.ConfigurationProvider).FirstOrDefaultAsync();
        return dto is null ? NotFound() : dto;
    }

    [HttpPost]
    public async Task<ActionResult<SupplierDto>> Create(SaveSupplierDto dto)
    {
        if (await db.Suppliers.AnyAsync(s => s.Name == dto.Name))
            return Conflict($"A supplier named '{dto.Name}' already exists.");

        var entity = mapper.Map<Supplier>(dto);
        db.Suppliers.Add(entity);
        await db.SaveChangesAsync();
        return CreatedAtAction(nameof(GetById), new { id = entity.SupplierId }, mapper.Map<SupplierDto>(entity));
    }

    [HttpPut("{id:int}")]
    public async Task<ActionResult<SupplierDto>> Update(int id, SaveSupplierDto dto)
    {
        var entity = await db.Suppliers.FindAsync(id);
        if (entity is null) return NotFound();
        if (await db.Suppliers.AnyAsync(s => s.Name == dto.Name && s.SupplierId != id))
            return Conflict($"A supplier named '{dto.Name}' already exists.");

        mapper.Map(dto, entity);
        await db.SaveChangesAsync();
        return mapper.Map<SupplierDto>(entity);
    }

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Delete(int id)
    {
        var entity = await db.Suppliers.FindAsync(id);
        if (entity is null) return NotFound();
        if (await db.PurchaseOrders.AnyAsync(p => p.SupplierId == id))
            return Conflict("This supplier has purchase orders. Set IsActive = false instead of deleting.");

        db.Suppliers.Remove(entity);
        await db.SaveChangesAsync();
        return NoContent();
    }
}
