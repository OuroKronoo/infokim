namespace RsciTicketing.Api.Controllers;

[ApiController]
[Route("api/purchase-orders")]
public class PurchaseOrdersController(PurchaseOrderService orders) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<List<PurchaseOrderDto>>> GetAll([FromQuery] string? status, [FromQuery] int? ticketId) =>
        await orders.ListAsync(status, ticketId);

    [HttpGet("{id:int}")]
    public async Task<ActionResult<PurchaseOrderDto>> GetById(int id) => await orders.GetAsync(id);

    [HttpPost]
    public async Task<ActionResult<PurchaseOrderDto>> Create(CreatePurchaseOrderDto dto)
    {
        var created = await orders.CreateAsync(dto);
        return CreatedAtAction(nameof(GetById), new { id = created.PurchaseOrderId }, created);
    }

    [HttpPut("{id:int}")]
    public async Task<ActionResult<PurchaseOrderDto>> Update(int id, UpdatePurchaseOrderDto dto) =>
        await orders.UpdateAsync(id, dto);

    /// <summary>"Delete" voids the P.O. (status Cancelled) - there is deliberately no hard delete.</summary>
    [HttpDelete("{id:int}")]
    public async Task<ActionResult<PurchaseOrderDto>> Void(int id, [FromQuery] int userId, [FromQuery] string? reason) =>
        await orders.VoidAsync(id, userId, reason);

    [HttpPost("{id:int}/approve")]
    public async Task<ActionResult<PurchaseOrderDto>> Approve(int id, ActorDto dto) => await orders.ApproveAsync(id, dto);

    [HttpPost("{id:int}/reject")]
    public async Task<ActionResult<PurchaseOrderDto>> Reject(int id, ReasonDto dto) => await orders.RejectAsync(id, dto);

    [HttpPost("{id:int}/rush")]
    public async Task<ActionResult<PurchaseOrderDto>> Rush(int id, ReasonDto dto) => await orders.RushAsync(id, dto);

    [HttpPost("{id:int}/order-of-payment")]
    public async Task<ActionResult<PurchaseOrderDto>> OrderOfPayment(int id, ActorDto dto) =>
        await orders.IssueOrderOfPaymentAsync(id, dto);

    [HttpPost("{id:int}/release-payment")]
    public async Task<ActionResult<PurchaseOrderDto>> ReleasePayment(int id, ActorDto dto) =>
        await orders.ReleasePaymentAsync(id, dto);

    [HttpPost("{id:int}/confirm-purchased")]
    public async Task<ActionResult<PurchaseOrderDto>> ConfirmPurchased(int id, ConfirmPurchasedDto dto) =>
        await orders.ConfirmPurchasedAsync(id, dto);

    [HttpPost("{id:int}/receive")]
    public async Task<ActionResult<PurchaseOrderDto>> Receive(int id, ActorDto dto) => await orders.ReceiveAsync(id, dto);
}
