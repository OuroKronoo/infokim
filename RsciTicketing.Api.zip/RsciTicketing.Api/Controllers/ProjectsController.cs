namespace RsciTicketing.Api.Controllers;

[ApiController]
[Route("api/projects")]
public class ProjectsController(RsciDbContext db, IMapper mapper, ActorService actors) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<List<ProjectDto>>> GetAll() =>
        await db.Projects.AsNoTracking().OrderBy(p => p.Name)
                .ProjectTo<ProjectDto>(mapper.ConfigurationProvider).ToListAsync();

    [HttpGet("{id:int}")]
    public async Task<ActionResult<ProjectDto>> GetById(int id)
    {
        var dto = await db.Projects.AsNoTracking().Where(p => p.ProjectId == id)
                          .ProjectTo<ProjectDto>(mapper.ConfigurationProvider).FirstOrDefaultAsync();
        return dto is null ? NotFound() : dto;
    }

    [HttpPost]
    public async Task<ActionResult<ProjectDto>> Create(SaveProjectDto dto)
    {
        if (await db.Projects.AnyAsync(p => p.Name == dto.Name))
            return Conflict($"A project named '{dto.Name}' already exists.");

        var entity = mapper.Map<Project>(dto);
        entity.DownpaymentStatus = DownpaymentStatus.None;   // always starts unpaid
        db.Projects.Add(entity);
        await db.SaveChangesAsync();
        return CreatedAtAction(nameof(GetById), new { id = entity.ProjectId }, mapper.Map<ProjectDto>(entity));
    }

    [HttpPut("{id:int}")]
    public async Task<ActionResult<ProjectDto>> Update(int id, SaveProjectDto dto)
    {
        var entity = await db.Projects.FindAsync(id);
        if (entity is null) return NotFound();
        if (await db.Projects.AnyAsync(p => p.Name == dto.Name && p.ProjectId != id))
            return Conflict($"A project named '{dto.Name}' already exists.");

        mapper.Map(dto, entity);   // DownpaymentStatus is not in the DTO, so it cannot be changed here
        await db.SaveChangesAsync();
        return mapper.Map<ProjectDto>(entity);
    }

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Delete(int id)
    {
        var entity = await db.Projects.FindAsync(id);
        if (entity is null) return NotFound();
        if (await db.Tickets.AnyAsync(t => t.ProjectId == id))
            return Conflict("This project already has tickets and cannot be deleted.");

        db.Projects.Remove(entity);
        await db.SaveChangesAsync();
        return NoContent();
    }

    /// <summary>
    /// Billing marks the downpayment invoice Paid. Every ticket of this project that was stuck
    /// waiting for a budget override goes back to po_creation.
    /// </summary>
    [HttpPost("{id:int}/downpayment/paid")]
    public async Task<ActionResult<ProjectDto>> MarkDownpaymentPaid(int id, ActorDto dto)
    {
        await actors.RequireAsync(dto.UserId, Roles.BillingAccountant);

        var project = await db.Projects.FindAsync(id);
        if (project is null) return NotFound();

        project.DownpaymentStatus = DownpaymentStatus.Paid;

        var waiting = await db.Tickets
            .Where(t => t.ProjectId == id && t.Status == TicketStatus.PendingOverride)
            .ToListAsync();
        foreach (var t in waiting) t.Status = TicketStatus.PoCreation;

        await db.SaveChangesAsync();
        return mapper.Map<ProjectDto>(project);
    }
}
