using AppUser = RsciTicketing.Api.Models.User;

namespace RsciTicketing.Api.Controllers;

[ApiController]
[Route("api/users")]
public class UsersController(RsciDbContext db, IMapper mapper) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<List<UserDto>>> GetAll([FromQuery] string? role) =>
        await db.Users.AsNoTracking()
                .Where(u => role == null || u.Role == role)
                .OrderBy(u => u.FullName)
                .ProjectTo<UserDto>(mapper.ConfigurationProvider)
                .ToListAsync();

    [HttpGet("{id:int}")]
    public async Task<ActionResult<UserDto>> GetById(int id)
    {
        var dto = await db.Users.AsNoTracking().Where(u => u.UserId == id)
                          .ProjectTo<UserDto>(mapper.ConfigurationProvider).FirstOrDefaultAsync();
        return dto is null ? NotFound() : dto;
    }

    [HttpPost]
    public async Task<ActionResult<UserDto>> Create(CreateUserDto dto)
    {
        if (!Roles.All.Contains(dto.Role))
            return BadRequest($"Unknown role '{dto.Role}'. Valid roles: {string.Join(", ", Roles.All)}.");
        if (await db.Users.AnyAsync(u => u.Email == dto.Email))
            return Conflict($"A user with email {dto.Email} already exists.");

        var entity = mapper.Map<AppUser>(dto);
        db.Users.Add(entity);
        await db.SaveChangesAsync();
        return CreatedAtAction(nameof(GetById), new { id = entity.UserId }, mapper.Map<UserDto>(entity));
    }
}
