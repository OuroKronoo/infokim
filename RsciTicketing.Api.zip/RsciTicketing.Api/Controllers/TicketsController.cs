namespace RsciTicketing.Api.Controllers;

[ApiController]
[Route("api/tickets")]
public class TicketsController(TicketService tickets) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<List<TicketDto>>> GetAll(
        [FromQuery] string? status, [FromQuery] int? projectId, [FromQuery] int? requestedById) =>
        await tickets.ListAsync(status, projectId, requestedById);

    [HttpGet("{id:int}")]
    public async Task<ActionResult<TicketDto>> GetById(int id) => await tickets.GetAsync(id);

    [HttpPost]
    public async Task<ActionResult<TicketDto>> Create(CreateTicketDto dto)
    {
        var created = await tickets.CreateAsync(dto);
        return CreatedAtAction(nameof(GetById), new { id = created.TicketId }, created);
    }

    [HttpPut("{id:int}")]
    public async Task<ActionResult<TicketDto>> Update(int id, UpdateTicketDto dto) =>
        await tickets.UpdateAsync(id, dto);

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Delete(int id, [FromQuery] int userId)
    {
        await tickets.DeleteAsync(id, userId);
        return NoContent();
    }

    [HttpPost("{id:int}/approve")]
    public async Task<ActionResult<TicketDto>> Approve(int id, ActorDto dto) => await tickets.ApproveAsync(id, dto);

    [HttpPost("{id:int}/reject")]
    public async Task<ActionResult<TicketDto>> Reject(int id, ReasonDto dto) => await tickets.RejectAsync(id, dto);

    [HttpPost("{id:int}/override")]
    public async Task<ActionResult<TicketDto>> Override(int id, ActorDto dto) => await tickets.OverrideAsync(id, dto);

    [HttpPost("{id:int}/release")]
    public async Task<ActionResult<TicketDto>> Release(int id, ActorDto dto) => await tickets.ReleaseAsync(id, dto);
}
